#ifndef CLIENTES_H_INCLUDED
#define CLIENTES_H_INCLUDED

typedef struct{
char nombre[100];
char apellido[100];
char dni[20];
int id;


}eCliente;
eCliente* cliente_new();
void cliente_delete();

int cliente_setNombre(eCliente* this,char* nombre);
int cliente_getNombre(eCliente* this,char* nombre);

int cliente_setApellido(eCliente* this,char* mail);
int cliente_getApellido(eCliente* this,char* mail);


int cliente_setDni(eCliente* this,char* mail);
int cliente_getDni(eCliente* this,char* mail);

int cliente_setId(eCliente* this, int id);
int cliente_getId(eCliente* this, int *id);

eCliente* cliente_newParametros(char* nombre,char* apellido, char* dni, int id);
#endif // CLIENTES_H_INCLUDED
