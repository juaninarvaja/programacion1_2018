#ifndef PRODUCTOS_H_INCLUDED
#define PRODUCTOS_H_INCLUDED
#include "ArrayList.h"
typedef struct{
int id;
float precio;
char nombre[100];
}eProducto;

eProducto* producto_altaForzadaProductos(char* nombre, float precio,int id);
int producto_getNombre(eProducto* this, char* nombre);
int producto_setNombre(eProducto* this, char* nombre);


int producto_setId(eProducto* this, int id);
int producto_getId(eProducto* this, int *id);

#endif // PRODUCTOS_H_INCLUDED


