
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "utn.h"
#include "clientes.h"
#include "ventas.h"
#include "productos.h"

 controller_leerArchivoyGuardarEnArrayCliente(char* path, ArrayList* pArrayClientes){
    char bNombre[4096];
    char bApellido[4096];
    char bDni[4056];
    int bId;

    eCliente* pAuxiliarCliente;
    FILE* pFile;
    int retorno = -1;
    pFile = fopen(path,"r");
    if(pFile != NULL)
    {
        retorno = 0;

        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[\n]\n",bId,bNombre,bApellido,bDni);
            pAuxiliarCliente = cliente_newParametros(bNombre,bApellido,bDni,bId);
            al_add(pArrayClientes,pAuxiliarCliente);

        }
    }
    fclose(pFile);
    return retorno;

 }
