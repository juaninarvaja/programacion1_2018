#ifndef PUBLICACION_H_INCLUDED
#define PUBLICACION_H_INCLUDED
typedef struct
{
    //------------
    int idePublicacion;
    int idCliente;
    int rubro;
    char textoAviso[60];
    int isEmpty;
    int isActive;
}ePublicacion;
#endif // PUBLICACION_H_INCLUDED


int publicacion_init(ePublicacion* arrayPublicacion,int limite);
int publicacion_mostrar(ePublicacion* arrayPublicacion,int limite);
int publicacion_mostrarDebug(ePublicacion* arrayPublicacion,int limite);
int publicacion_alta(ePublicacion* arrayPublicacion,int limite);
int publicacion_baja(ePublicacion* arrayPublicacion,int limite, int id);
int publicacion_modificacion(ePublicacion* arrayPublicacion,int limite, int id);
int publicacion_ordenar(ePublicacion* arrayPublicacion,int limite, int orden);
int publicacion_buscarLugarLibre(ePublicacion* arrayPublicacion,int limite);
int publicacion_proximoId();
int publicacion_altaForzada(ePublicacion* arrayPublicacion,int tam,char* aviso,int IdCliente,int rubro);
int publicacion_buscaIdCliente(ePublicacion *arrayPublicacion, int tam, int id);
int publicacion_pausarPublicacion(ePublicacion *arrayPublicacion, int tam, int id);
int publicacion_ActivarPublicacion(ePublicacion *arrayPublicacion,int tam, int id);
void publicacion_mostrarPausadas(ePublicacion* arrayPublicacion, int tam);
;
