#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "publicacion.h"
#include "utn.h"
#include "cliente.h"

/** \brief
 * \param arrayPublicacionePublicacion*
 * \param limite int
 * \return int
 *
 */
int publicacion_init(ePublicacion* arrayPublicacion,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayPublicacion!= NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            arrayPublicacion[i].isEmpty=1;
        }
    }
    return retorno;
}

int publicacion_mostrarDebug(ePublicacion* arrayPublicacion,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayPublicacion!= NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - %d - %s - %d\n",arrayPublicacion[i].idePublicacion, arrayPublicacion[i].textoAviso, arrayPublicacion[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_mostrar(ePublicacion* arrayPublicacion,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayPublicacion!= NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!arrayPublicacion[i].isEmpty)
                printf("[RELEASE] - %d - %s - %d\n",arrayPublicacion[i].idePublicacion, arrayPublicacion[i].textoAviso, arrayPublicacion[i].isEmpty);
        }
    }
    return retorno;
}

int publicacion_alta(ePublicacion* arrayPublicacion,int limite)
{
    int retorno = -1;
    int i, auxInt;
    char buffer[50];
    if(limite > 0 && arrayPublicacion!= NULL)
    {
        i = publicacion_buscarLugarLibre(arrayPublicacion,limite);
        if(i >= 0)
        {
            getString("Ingrese el mensaje a publicar",buffer);
            retorno = 0;
            strcpy(arrayPublicacion[i].textoAviso,buffer);
            printf("ingrese numero de rubro");
            scanf("%d",&auxInt);
            arrayPublicacion[i].rubro = auxInt;
            printf("ingrese id de cliente");
            scanf("%d",&auxInt);
            arrayPublicacion[i].idCliente = auxInt;
                //------------------------------
                //------------------------------
                arrayPublicacion[i].idePublicacion = publicacion_proximoId();
                arrayPublicacion[i].isEmpty = 0;
                arrayPublicacion[i].isActive = 1;
                printf("El ID es: %d", arrayPublicacion[i].idePublicacion);
            }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}


int publicacion_baja(ePublicacion* arrayPublicacion,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayPublicacion!= NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!arrayPublicacion[i].isEmpty && arrayPublicacion[i].idePublicacion==id)
            {
                arrayPublicacion[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}




int publicacion_modificacion(ePublicacion* arrayPublicacion,int limite, int id)
{
    int retorno = -1;
    int i;
    char buffer[50];
    if(limite > 0 && arrayPublicacion!= NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!arrayPublicacion[i].isEmpty && arrayPublicacion[i].idePublicacion==id)
            {
                if(!getValidString("\nAviso? ","\nEso no es un Aviso","El maximo es 60",buffer,60,2))
                {
                    retorno = 0;
                    strcpy(arrayPublicacion[i].textoAviso,buffer);
                    //------------------------------
                    //------------------------------
                }
                else
                {
                    retorno = -3;
                }
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

int publicacion_ordenar(ePublicacion* arrayPublicacion,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    ePublicacion auxiliarEstructura;

    if(limite > 0 && arrayPublicacion!= NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!arrayPublicacion[i].isEmpty && !arrayPublicacion[i+1].isEmpty)
                {
                    if((strcmp(arrayPublicacion[i].textoAviso,arrayPublicacion[i+1].textoAviso) > 0 && orden) || (strcmp(arrayPublicacion[i].textoAviso,arrayPublicacion[i+1].textoAviso) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = arrayPublicacion[i];
                        arrayPublicacion[i] = arrayPublicacion[i+1];
                        arrayPublicacion[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

int publicacion_buscarLugarLibre(ePublicacion* arrayPublicacion,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayPublicacion!= NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(arrayPublicacion[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


int publicacion_proximoId()
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}

int publicacion_altaForzada(ePublicacion* arrayPublicacion,int tam,char* aviso,int IdCliente,int rubro)
{
    int retorno = -1;
    int i;

    if(tam > 0 && arrayPublicacion != NULL)
    {
        i = publicacion_buscarLugarLibre(arrayPublicacion,tam);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(arrayPublicacion[i].textoAviso,aviso);
            arrayPublicacion[i].rubro = rubro;
            arrayPublicacion[i].idCliente = IdCliente;
            //------------------------------
            //------------------------------
            arrayPublicacion[i].idePublicacion = publicacion_proximoId();
            arrayPublicacion[i].isEmpty = 0;
        }
        retorno = 0;
    }
    return retorno;
}

int publicacion_buscaIdCliente(ePublicacion *arrayPublicacion, int tam, int id){
int i;
int retorno = -1;
for(i=0; i<tam;i++){
    if(arrayPublicacion[i].idCliente == id){

        printf(" \n %s   id Cliente: %d \n",arrayPublicacion[i].textoAviso,arrayPublicacion[i].idCliente);
        publicacion_baja(arrayPublicacion,tam,arrayPublicacion[i].idCliente);
        retorno = 1;
    }

}
return retorno;

}


int publicacion_pausarPublicacion(ePublicacion *arrayPublicacion, int tam, int id){
int i;
int retorno = -1;
for(i = 0; i < tam; i++){
    if(arrayPublicacion[i].idePublicacion == id && !arrayPublicacion[i].isEmpty){
        arrayPublicacion[i].isActive = 0;
        printf(" \n pausada con exito \n");
        retorno = 1;

    }
}
return retorno;
}

void publicacion_mostrarPausadas(ePublicacion* arrayPublicacion, int tam){
    int i;
    for(i = 0; i< tam; i++){
        if(arrayPublicacion[i].isActive == 0){

            printf("%\n aviso : %s , \n id Publicacion Pausada: %d",arrayPublicacion[i].textoAviso,arrayPublicacion[i].idePublicacion);
        }
        }
}

int publicacion_ActivarPublicacion(ePublicacion* arrayPublicacion, int tam, int id){
int i;
int retorno = -1;
for(i = 0; i < tam; i++){
    if(arrayPublicacion[i].idePublicacion == id && !arrayPublicacion[i].isEmpty){
        arrayPublicacion[i].isActive = 1;
        printf(" \n Activada con exito \n");
        retorno = 1;

    }
}
return retorno;
}

