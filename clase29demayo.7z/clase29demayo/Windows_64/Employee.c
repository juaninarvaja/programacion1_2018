#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "Employee.h"

static int isValidName(char* name);
static int isValidLastName(char* lastName);
static int isValidIsEmpty(int isEmpty);



int employee_compare(void* pEmployeeA,void* pEmployeeB)
{
    char nameA[51];
    char nameB[51];
    employee_getNombre(pEmployeeA,nameA);
    employee_getNombre(pEmployeeB,nameB);

    return strcmp(nameA,nameB);
}


void employee_print(Employee* this)
{
    int id;
    char name[51];
    char lastName[51];
    int isEmpty;
    employee_getNombre(this,name);
    employee_getApellido(this,lastName);
    employee_getId(this, &id);
    employee_getIsEmpty(this, &isEmpty);

    printf("\n Nombre:%s - Id: %d - isEmpty %d \n",name,id, isEmpty);
}


Employee* employee_new(void)
{
    Employee* returnAux = NULL;
    returnAux = (Employee*)malloc(sizeof(Employee));
    return returnAux;

}
Employee* employee_newParametrosString(char* strId, char*strName,char*strLastName,char* strIsEmpty)
{
    Employee* this;
    int id;
    int isEmpty = 0;

    id = atoi(strId); //falta validar q sea numero
    if(!strcmp(strIsEmpty,"true")){
        isEmpty = 1;
    }
    this = employee_new();
    employee_setId(this,id);
    employee_setIsEmpty(this,isEmpty);
    employee_setNombre(this,strName);
    employee_setApellido(this,strLastName);

    return this;
}


void employee_delete(Employee* this)
{
    if(this != NULL){
        free(this);
}
}

int employee_setId(Employee* this, int id)
{
    int retorno = -1;
    static int maximoId = -1;
     if(this != NULL ){
        retorno =0;
        if(id >= 0){
            if(id > maximoId){
                maximoId = id;
                this->id = id;
            }
        }
        else{
            maximoId ++;
            this->id =maximoId;
        }

        }
    return retorno;

}

int employee_getId(Employee* this, int *id)
{
    int retorno = -1;
     if(this != NULL && id !=NULL){
        *id = this->id;
        retorno =0;
        }
    return retorno;
}

int employee_setNombre(Employee* this, char* nombre){
    int retorno = -1;
    if(this != NULL && nombre != NULL && isValidName(nombre)){
        strcpy(this->name, nombre);
        retorno = 0;

    }
return retorno;
}


int employee_getNombre(Employee* this, char* nombre){
    int retorno = -1;
    if(this != NULL){
        strcpy(nombre, this->name);
        retorno = 0;
    }
return retorno;
}

int employee_setApellido(Employee* this, char* apellido){
    int retorno = -1;
    if(this != NULL && apellido != NULL && isValidLastName(apellido)){
        strcpy(this->lastName,apellido);
        retorno = 0;

    }
return retorno;
}


int employee_getApellido(Employee* this, char* apellido){
    int retorno = -1;
    if(this != NULL){
        strcpy(apellido, this->lastName);
        retorno = 0;
    }
return retorno;
}

int employee_getIsEmpty(Employee* this, int* isEmpty){
    int retorno = -1;
    if(this != NULL && isEmpty != NULL){

        retorno = 0;
       *isEmpty = this->isEmpty;
    }

    return retorno;
}

int employee_setIsEmpty(Employee* this, int isEmpty)
{
    int retorno = -1;

     if(this != NULL && isValidIsEmpty(isEmpty)){
        retorno =0;

        this->isEmpty = isEmpty;
            }
    return retorno;

}


static int isValidName(char* name){
    return 1;
}

static int isValidLastName(char* lastName){
    return 1;
}

static int isValidIsEmpty(int isEmpty){
    return 1;
}
