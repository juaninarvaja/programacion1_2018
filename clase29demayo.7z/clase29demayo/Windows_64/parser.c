#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "Employee.h"
#include "parser.h"

int parserEmployee(FILE* pFile , ArrayList* pArrayListEmployee)
{
  Employee* auxEmpleado;
   char id[4096];
   char name[4096];
   char lastName[4096];
   char isEmpty[4096];
    int retorno = -1;

   if(pFile != NULL){
         fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",id,name,lastName,isEmpty);
         retorno = 0;

        while(!feof(pFile)){

            fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",id,name,lastName,isEmpty);
            //printf("ID %s \n", id);
           auxEmpleado = employee_newParametrosString(id,name,lastName,isEmpty);
           al_add(pArrayListEmployee,auxEmpleado);
        }


        }

    return retorno;
}
