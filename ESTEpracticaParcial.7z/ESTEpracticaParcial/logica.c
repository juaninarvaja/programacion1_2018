#include <stdio.h>
#include <stdlib.h>
#include "logica.h"
#include "funcs.h"
int menu(){
int opcion;

system("cls");
printf(" -------- BIENVENIDO A MERCADOLIBRE ------ \n \n");
printf("1. ALTA DE USUARIO\n2. MODIFICAR DATOS DEL USUARIO\n3. BAJA DEL USUARIO\n4. PUBLICAR PRODUCTO\n5. MODIFICAR PUBLICACION.\n6. CANCELAR PUBLICACION\n7. COMPRAR PRODUCTO: \n8. LISTAR PUBLICACIONES DE USUARIO\n9. LISTAR PUBLICACIONES\n10. LISTAR USUARIOS \n11.SALIR \n \n");
scanf("%d", &opcion);
while(opcion < 1 || opcion > 11){
    printf("Error! reingrese opcion");
    scanf("%i", &opcion);

}
return opcion;
}
