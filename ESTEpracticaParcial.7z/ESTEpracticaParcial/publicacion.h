#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
char nombre[50];
float precio;
int stock;
int idProducto;
int isEmpty;
int idUsuario;
}eProducto;


void inicializarProductos(eProducto arrayProducto[], int tam);
int buscaLibreProd(eProducto arrayProducto[], int tam);
void altaProductos(eProducto arrayProducto[], int tam);
