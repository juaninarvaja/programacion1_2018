#include <stdio.h>
#include <stdlib.h>
#include <string.h>


typedef struct{
char nombreUsuario[25];
char password[25];
int idUsuario;
int isEmpty; //1 si esta vacio 0 si ocupado
}eUsuario;

void inicializarUsuarios(eUsuario arrayUsuario[], int tam);
void altaUsuario(eUsuario arrayUsuario[], int tam);
int buscaLibre(eUsuario arrayUsuario[], int tamanioArray);
void listarUsuarios(eUsuario arrayUsuario[], int tam);
void modificarUsuario(eUsuario arrayUsuario[], int tam, int identificador);
int buscaIdAlta(eUsuario arrayUsuario[], int tam, int id);
void eliminarUsuario(eUsuario arrayUsuario[], int tam, int id);
