#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "usuarios.h"
#include "funcs.h"
void inicializarUsuarios(eUsuario arrayUsuario[], int tam){
int i;
for(i=0; i < tam; i++)
    {
        arrayUsuario[i].isEmpty = 1;
        arrayUsuario[i].idUsuario = 1000 + i;
    }
}

int buscaLibre(eUsuario arrayUsuario[], int tamanioArray){
int i;
for(i = 0; i < tamanioArray; i++){
   if(arrayUsuario[i].isEmpty == 1)
    {
        return i;
        break;
    }
  }
    return -1;
}


void altaUsuario(eUsuario arrayUsuario[], int tam)
{

    eUsuario auxUsuario;
    int i = buscaLibre(arrayUsuario,tam);

    if(i != -1){
    arrayUsuario[i].isEmpty = 0;
    printf("hay lugar, ingrese \n ");

    printf(" \n ingrese el nombre de usuario \n");
    fflush(stdin);
    gets(auxUsuario.nombreUsuario);
    strcpy(arrayUsuario[i].nombreUsuario,auxUsuario.nombreUsuario);

    printf("\n ingrese la contrase�a \n");
    fflush(stdin);
    gets(arrayUsuario[i].password);

    printf("\n Usuario  Cargado \n");
}
    else printf("NO HAY LUGAR");
}

void listarUsuarios(eUsuario arrayUsuario[], int tam){
int i;
for(i = 0; i < tam; i++)
    {
        if(arrayUsuario[i].isEmpty == 0){
            printf("USUARIO \t  ID  \t CONTRASE�A \n ");
            printf("%s \t %i \t %s \n", arrayUsuario[i].nombreUsuario, arrayUsuario[i].idUsuario, arrayUsuario[i].password);

        }

    }



}


void modificarUsuario(eUsuario arrayUsuario[], int tam, int identificador)
{
int i;
for(i = 0; i < tam; i++){
    if(identificador == arrayUsuario[i].idUsuario){
        printf("ingreso a la modifiacion de datos del usuario %s  ", arrayUsuario[i].nombreUsuario);
        printf("\n ingrese nuevo usuario ");
        fflush(stdin);
        gets(arrayUsuario[i].nombreUsuario);
        printf("ingrese nueva contrase�a ");
        fflush(stdin);
        gets(arrayUsuario[i].password);

    }



}


}

int buscaIdAlta(eUsuario arrayUsuario[], int tam, int id){
int i;
for(i = 0; i < tam; i++){
    if(arrayUsuario[i].idUsuario == id && arrayUsuario[i].isEmpty == 0){
        return i;
        break;
    }

}
return -1;
}
void eliminarUsuario(eUsuario arrayUsuario[], int tam, int id){
int i;
for(i = 0; i < tam; i++){
    if(arrayUsuario[i].idUsuario == id && arrayUsuario[i].isEmpty == 0){
        arrayUsuario[i].isEmpty = 1;
        printf("\n USUARIO ELIMINADO \n");
        break;
    }
}
}
