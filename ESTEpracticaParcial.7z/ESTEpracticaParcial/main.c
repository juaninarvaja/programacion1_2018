#include <stdio.h>
#include <stdlib.h>
#include "usuarios.h"
#include "publicacion.h"
#include "logica.h"
#include "funcs.h"
#define TAM_USR 2
#define TAM_PRD 10

int main()
{
eUsuario arrayUsuarios[TAM_USR];
eProducto arrayProductos[TAM_PRD];

inicializarUsuarios(arrayUsuarios, TAM_USR);
inicializarProductos(arrayProductos, TAM_PRD);
    int opcion;
    int identificador;
    int retorno;
    int auxId;
do{
    switch(opcion = menu())
    {
     case 1:
            printf("\n ----- ALTA DE USUARIOS -----\n");
            altaUsuario(arrayUsuarios, TAM_USR);
            system("pause");
         break;
     case 2:printf("\n ----- MODIFICACION DE USUARIOS -----\n");
            listarUsuarios(arrayUsuarios, TAM_USR);
            retorno = getInt("Ingrese id a modificar", "Error!", 5, 999,3000,&identificador);
            auxId = buscaIdAlta(arrayUsuarios,TAM_USR,identificador);
           if(retorno == 0 && auxId != -1){
            modificarUsuario(arrayUsuarios,TAM_USR,identificador);
            }
            else printf("no existe ese ID");
            system("pause");
         break;
     case 3: printf("\n ----- ELIMINAR USUARIOS -----\n");
             listarUsuarios(arrayUsuarios, TAM_USR);
             retorno = getInt("Ingrese id a eliminar", "Error!", 5, 999,3000,&identificador);
            auxId = buscaIdAlta(arrayUsuarios,TAM_USR,identificador);
           if(retorno == 0 && auxId != -1){
            eliminarUsuario(arrayUsuarios,TAM_USR,identificador);
            }
            else printf("no existe ese ID");
            system("pause");
         break;
     case 4: altaProductos(arrayProductos, TAM_PRD);
            system("pause");
         break;
     case 5:
            system("pause");
         break;
     case 6:
            system("pause");
         break;
     case 7:
            system("pause");
         break;
     case 8:
            system("pause");
         break;
     case 9:
            system("pause");
         break;
     case 10:
            system("pause");
         break;
     case 11: opcion = -1;
         break;
    }


}while(opcion != -1);


return 0;
}
