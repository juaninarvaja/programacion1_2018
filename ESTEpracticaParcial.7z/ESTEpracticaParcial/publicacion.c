#include <stdio.h>
#include <stdlib.h>
#include "publicacion.h"
#include "funcs.h"
void inicializarProductos(eProducto arrayProducto[], int tam){
int i;
for(i=0; i < tam; i++)
    {
        arrayProducto[i].isEmpty = 1;
        arrayProducto[i].idProducto = 2000 + i;
    }

}

int buscaLibreProd(eProducto arrayProducto[], int tam){
int i;
for(i = 0; i < tam; i++){
   if(arrayProducto[i].isEmpty == 1)
    {
        return i;
        break;
    }
  }
    return -1;
}


void altaProductos(eProducto arrayProducto[], int tam){
    eProducto auxProduc;
    int auxStock;
    int i = buscaLibreProd(arrayProducto,tam);

    if(i != -1){
    arrayProducto[i].isEmpty = 0;
    printf("hay lugar, ingrese \n ");

    printf(" \n ingrese el nombre del producto\n");
    fflush(stdin);
    gets(auxProduc.nombre);
    strcpy(arrayProducto[i].nombre,auxProduc.nombre);
    printf("\n Ingrese el precio del producto  \n");
    scanf("%f", &arrayProducto[i].precio);
    arrayProducto[i].stock = getInt("Ingrese el stock","Error!",5,0,10000,&auxStock);

    printf("ingrese la Id del usuario que sube el producto");


    printf("\n Producto Cargado \n");
}
    else printf("NO HAY LUGAR");
}
