#include <stdio.h>
#include <stdlib.h>
#include "persona.h"



int main()
{
   /* int* a;
    int* pAux;
    a = (int*)malloc(sizeof(int));//Lo casteo para evitarme el warning(*int)
    pAux = (int*)realloc(a,sizeof(int)*100);
    if(pAux != NULL){
        *a = 22;
        printf(" A ES %i \n", *a);
        }
     */
 int edad;
 char alumno[100];
    eAlumno* arrayPunteroAlumnos[50]; //50 punteros a alumnos, ocucpa el lugar de 50 int;
    cargar(arrayPunteroAlumnos,50);
    mostrar(arrayPunteroAlumnos,50);

     alumno_setEdad(arrayPunteroAlumnos,8);
     alumno_getEdad(arrayPunteroAlumnos,&edad);
    printf("%d",edad);
    alumno_setNombre(arrayPunteroAlumnos,'jose');
    alumno_getEdad(arrayPunteroAlumnos,alumno);
     printf("%s",alumno);

    return 0;
}



