
typedef struct{

char nombre[50];
int edad;
int idPersona;
}eAlumno;

void cargar(eAlumno** arrayAlumno, int tam); //tambien lo podes recibir como * arrayAlumno[], (estas recibiendo un puntero al Array "**")
void mostrar(eAlumno** arrayAlumno, int tam);
eAlumno* alumno_new(); //Crea un Alumno/ constructor/
void alumno_delete(eAlumno* this); //this = puntero a alumno; / libera espacio en memoria / destructor/
int alumno_setEdad(eAlumno* this, int edad);
int alumno_getEdad(eAlumno* this, int* edad);
int alumno_setNombre(eAlumno* this, char* nombre);
int alumno_getNombre(eAlumno* this, char* nombre);
