#include <stdio.h>
#include <stdlib.h>
#include "persona.h"
#include <string.h>
void cargar(eAlumno** array,int tam){
    int i;
    eAlumno* auxiliarAlumno;
    for(i=0; i<tam;i++){
        auxiliarAlumno = alumno_new();
         *(array+i) = auxiliarAlumno;
        alumno_setEdad(auxiliarAlumno, i+10);
}
}
void mostrar(eAlumno** array,int tam){
    int auxiliarEdad;
    for(;tam > 0;array++,tam --){
        alumno_getEdad(*array,&auxiliarEdad);

    }
}
eAlumno* alumno_new(){
    return malloc(sizeof(eAlumno));
}

void alumno_delete(eAlumno* this){
    free(this);
}

int alumno_setEdad(eAlumno* this, int edad){
    int retorno = -1;
    if(this != NULL && edad >= 0){
        this->edad = edad;
        retorno = 0;
    }
    return retorno;
}

int alumno_getEdad(eAlumno* this, int* edad){
    int retorno = -1;
    if(this != NULL && edad != NULL){

        *edad = this->edad;
        retorno = 0;
        }
    return retorno;
}

int alumno_setNombre(eAlumno* this, char* nombre){
    int retorno = -1;
    if(this != NULL && nombre >= 0){

        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;

}
int alumno_getNombre(eAlumno* this, char* nombre){
    int retorno = -1;
    if(this != NULL && nombre != NULL){

        strcpy(*nombre,this->nombre);
         retorno = 0;
        }
    return retorno;

}
