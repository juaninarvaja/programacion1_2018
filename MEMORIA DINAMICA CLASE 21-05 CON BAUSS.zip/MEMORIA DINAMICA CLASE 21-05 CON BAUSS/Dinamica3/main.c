#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main()
{
    int* vec;
    int* aux;
    vec = (int*) malloc (TAM*sizeof(int)); //int vec[TAM]; equivalente
    int i;

    if(vec == NULL){
        printf("No se pudo conseguir Memoria \n \n");
        system("pause");
        exit(1);
    }

    for(i = 0; i <TAM; i++){
        printf("ingrese un numero");
        scanf("%d",vec +i); // lo guardo en esa direccion de memoria
    }
     for(i = 0; i <TAM; i++){
        printf("    %d", *(vec+i)); //para printear lo que apunta en esa direccion de memoria
    }
    printf("\n \n");
    aux  = (int*)realloc(vec, (TAM + 5) * sizeof(int)); // me quede corto de espacio, ahora necesito 10, lo paso a un auxiliar par ano perder el puntero en caso de que quede en NULL

    if(aux == NULL){
        printf("no se pudo conseguir memoria");
        system("pause");
        exit(1);
    }
    else{
        vec = aux;

         for(i = 5; i <(TAM+5); i++){
            printf("ingrese un numero");
            scanf("%d",vec +i); // lo guardo en esa direccion de memoria
                }
        for(i = 5; i <(TAM+5); i++){
            printf("    %d", *(vec+i)); //para printear lo que apunta en esa direccion de memoria
            }

    }
    vec = (int*)realloc(vec,TAM * sizeof(int));//SI ME achico no va a correr el riesgo de que devuelva null

    free(vec);
    return 0;
}
