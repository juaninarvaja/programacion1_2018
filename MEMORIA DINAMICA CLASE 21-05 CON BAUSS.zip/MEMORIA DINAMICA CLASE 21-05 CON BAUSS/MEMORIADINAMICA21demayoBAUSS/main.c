#include <stdio.h>
#include <stdlib.h>

int main()
{
    int * pNum;
    pNum = (int*)malloc(sizeof(int)); //me busca donde puedo empezar a trabajar con ese espacio y me duvuelve la primer direccion de memoria
    if(pNum == NULL){
        printf("no se pudo conseguir memoria. El programa finaliza \n\n");
         system("pause");
        exit(1);
    }
    *pNum = 5; //cargo 5 dentro de la direccion de memoria q me paso el malloc
    printf("%d \n\n", *pNum); //imprimo * (a lo que esta dentro de la direccion qqeu apunta) pNum es decir 5
    printf("ingrese un numero");
    scanf("%d",pNum); //en scanf no es necsario poner el ampersant, ya que de por si el puntero ya es una direccion de memora
    printf("%d \n\n", *pNum);
    //siempre antes de cerrar el programa tengo que liberar los espacios en memoria que reserve con el malloc ya que sino quedan guardados
    free(pNum);


    return 0;
}
