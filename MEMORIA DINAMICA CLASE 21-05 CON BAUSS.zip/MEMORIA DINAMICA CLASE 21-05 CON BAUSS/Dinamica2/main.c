#include <stdio.h>
#include <stdlib.h>
#define TAM 5
int main()
{
    //int vec[TAM]; equivalente
    int* vec;
    vec = (int*) malloc (TAM*sizeof(int)); //int vec[TAM]; equivalente
    int i;

    if(vec == NULL){
        printf("No se pudo conseguir Memoria \n \n");
        system("pause");
        exit(1);
    }

    for(i = 0; i <TAM; i++){
        printf("ingrese un numero");
        scanf("%d",vec +i); // lo guardo en esa direccion de memoria
    }
     for(i = 0; i <TAM; i++){
        printf("    %d", *(vec+i)); //para printear lo que apunta en esa direccion de memoria

    }
        free(vec);
    return 0;
}
