﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Persona
    {
        public string nombre;
        public int edad;
        public Persona(string nombre, int edad){
            this.edad = edad;
            this.nombre = nombre;
        }
        public Persona(string nombre) {
            this.edad = 0;
            this.nombre = nombre;
        }
        public string getNombre() {
            return this.nombre;
        }
        public void setNombre(string nombre) {
            this.nombre = nombre;
        }
        public int getEdad() {
            return this.edad;
        }
        public void setEdad(int edad) {
            this.edad = edad;
        }
    }
}
