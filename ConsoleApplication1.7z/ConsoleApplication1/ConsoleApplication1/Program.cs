﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona j = new Persona("Juan",21);
            Persona p = new Persona("Mario2",12);
            Persona i = new Persona("Mario3", 28);
            Persona z = new Persona("Mario4",17);

            List<Persona> listaPersona = new List<Persona>();
            listaPersona.Add(j);
            listaPersona.Add(p);
            listaPersona.Add(i);
            listaPersona.Add(z);
            int init = 0;
            for (init = 0; init < listaPersona.Count; init++) {
                if (listaPersona[init].edad > 19) {
                    
                    Console.WriteLine("Este usuario es mayor: " + listaPersona[init].getNombre());
                    Console.ReadKey();
                }
            
            }


            

        }
    }
}
