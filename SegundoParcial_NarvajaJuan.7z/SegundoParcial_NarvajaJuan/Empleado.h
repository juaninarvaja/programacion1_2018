#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED

typedef struct
{
  int id;
  char nombre[128];
  int horasTrabajadas;
}eEmpleado;

eEmpleado* empleado_new();
void empleado_delete(eEmpleado* this);
int empleado_trabajaMasDe120Horas(eEmpleado* unEmpleado);
//int em_trabajaMasDe120Horas(void* item);

eEmpleado* empleado_newParametros(int id, char* nombre, int horas);
int empleado_getHoras(eEmpleado* this, int *horas);
int empleado_setHoras(eEmpleado* this, int horas);
int empleado_getNombre(eEmpleado* this,char* nombre);
int empleado_setNombre(eEmpleado* this,char* nombre);
int empleado_getId(eEmpleado* this, int *id);
int empleado_setId(eEmpleado* this, int id);

#endif // EMPLEADO_H_INCLUDED
