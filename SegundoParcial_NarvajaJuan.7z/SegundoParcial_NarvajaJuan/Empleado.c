#include "Empleado.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "utn.h"
#include "controller.h"

eEmpleado* empleado_new()
{
    eEmpleado* this;
    this=malloc(sizeof(eEmpleado));
    return this;
}
void empleado_delete(eEmpleado* this)
{
    free(this);
}

int empleado_setId(eEmpleado* this, int id)
{
    int retorno = -1;
    static int maximoId = -1;
    if(this != NULL)
    {
        retorno = 0;
        if(id >= 0)
        {
            this->id = id;
            if(id > maximoId)
                maximoId = id;
        }
        else
        {
            maximoId++;
            this->id = maximoId;
        }
    }
    return retorno;
}

int empleado_getId(eEmpleado* this, int *id)
{
    int retorno = -1;
     if(this != NULL && id !=NULL){
        *id = this->id;
        retorno =0;
        }
    return retorno;
}
int empleado_setNombre(eEmpleado* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int empleado_getNombre(eEmpleado* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}


int empleado_setHoras(eEmpleado* this, int horas)
{
    int retorno = -1;
     if(this != NULL ){
        retorno =0;

            this->horasTrabajadas = horas;
        }
    return retorno;
}

int empleado_getHoras(eEmpleado* this, int *horas)
{
    int retorno = -1;
     if(this != NULL && horas !=NULL){
        *horas= this->horasTrabajadas;
        retorno =0;
        }
    return retorno;
}





int empleado_trabajaMasDe120Horas(eEmpleado* unEmpleado)
{
int retorno = -1;
//eEmpleado* auxEmpleado;
int auxHoras;
if(unEmpleado != NULL)
    {
        retorno = 0;
    empleado_getHoras(unEmpleado,&auxHoras);
    if(auxHoras > 120)
        {
        retorno = 1;
        }
    }
return retorno;
}

eEmpleado* empleado_newParametros(int id, char* nombre, int horas)
{

    eEmpleado* auxEmpleado = empleado_new();
    if(!empleado_setId(auxEmpleado,id) && !empleado_setNombre(auxEmpleado,nombre) && !empleado_setHoras(auxEmpleado,horas))
    {
        return auxEmpleado;
    }

    empleado_delete(auxEmpleado);
    return NULL;
}
