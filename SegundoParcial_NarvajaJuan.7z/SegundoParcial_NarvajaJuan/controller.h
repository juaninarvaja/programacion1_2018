#ifndef CONTROLLER_H_INCLUDED
#define CONTROLLER_H_INCLUDED
int controller_leerArchivoyGuardarEnArray(char* path, ArrayList* this);
 int controller_verificaEmpleados(ArrayList* this);
  int controller_mostrarEmpleados(ArrayList* this);
   int controller_guardarEmpleadosArchivo(char* path, ArrayList* pArrayEmpleados);


#endif // CONTROLLER_H_INCLUDED
