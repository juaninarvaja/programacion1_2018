#include <stdio.h>
#include <stdlib.h>
#include "utn.h"
#include "ArrayList.h"
#include "controller.h"

int main()
{

    ArrayList* pArrayEmpleados;
    pArrayEmpleados = al_newArrayList();
    controller_leerArchivoyGuardarEnArray("data.csv",pArrayEmpleados);
    controller_verificaEmpleados(pArrayEmpleados);

return 0;
}
