#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "utn.h"
#include "controller.h"
#include "Empleado.h"

int controller_leerArchivoyGuardarEnArray(char* path, ArrayList* this)
{
   char bNombre[4096];
    char bId[4056];
    char bHoras[4056];

    eEmpleado* pAuxiliarEmpleado;
    FILE* pFile;
    int retorno = -1;
    pFile = fopen(path,"r");
    int idEste;
    int horasEste;
    if(pFile != NULL)
    {
        retorno = 0;
        fscanf(pFile,"%[^,],%[^,],%[^\n]\n",bId,bNombre,bHoras);
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^\n]\n",bId,bNombre,bHoras);
            idEste = atoi(bId);
            horasEste = atoi(bHoras);
            pAuxiliarEmpleado = empleado_newParametros(idEste,bNombre,horasEste);
            al_add(this,pAuxiliarEmpleado);
        }
    }
    fclose(pFile);
    return retorno;
 }

 int controller_verificaEmpleados(ArrayList* this)
 {
     // eEmpleado* auxEmpleado;
     //auxEmpleado = al_get(this,1);

    ArrayList* pArrayEmpleadosJornadaCompleta;
    pArrayEmpleadosJornadaCompleta = al_newArrayList();

    pArrayEmpleadosJornadaCompleta = al_filter(this,empleado_trabajaMasDe120Horas);
    controller_mostrarEmpleados(pArrayEmpleadosJornadaCompleta);
    controller_guardarEmpleadosArchivo("jornada_completa.txt",pArrayEmpleadosJornadaCompleta);
    return 0;
 }

 int controller_mostrarEmpleados(ArrayList* this)
 {
     int retorno = -1;
    int i;
    eEmpleado* auxiliarEmpleado;
    char nombre[64];
    int id;
    int horas;


    if(this != NULL){
        retorno = 0;
        for(i = 0; i < al_len(this);i++)
        {
            auxiliarEmpleado= al_get(this,i);
            empleado_getNombre(auxiliarEmpleado,nombre);
            empleado_getId(auxiliarEmpleado,&id);
            empleado_getHoras(auxiliarEmpleado,&horas);
            printf("%d,%s,%d\n",id,nombre,horas);

        }

    }


return retorno;
 }

 int controller_guardarEmpleadosArchivo(char* path, ArrayList* pArrayEmpleados)
{
    int retorno = -1;
    int i;
    eEmpleado* auxiliarEmpleado;
    char nombre[64];
    int id;
    int horas;
    FILE* pFile;
    pFile = fopen(path,"w+");
    if(pFile != NULL)
    {
    //fprintf(pFile,"id,nombre,apellido,dni\n");
        for(i=0;i<al_len(pArrayEmpleados);i++)
        {
            auxiliarEmpleado = al_get(pArrayEmpleados,i);
            empleado_getId(auxiliarEmpleado,&id);
            empleado_getNombre(auxiliarEmpleado,nombre);
            empleado_getHoras(auxiliarEmpleado,&horas);
            fprintf(pFile,"%d,%s,%d\n",id,nombre,horas);
        }
    }
    fclose(pFile);


    return retorno;
}


