#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "utn.h"
#include "controller.h"
#include "Producto.h"
#include "view.h"
int controller_leerArchivoyGuardarEnArray(char* path, ArrayList* this)
{
   char bNombre[4096];
    char bId[4056];
    char bCantidad[4056];

    eProducto* pAuxiliarProducto;
    FILE* pFile;
    int retorno = -1;
    pFile = fopen(path,"r");
    int idEste;
    int cantidadEste;
    if(pFile != NULL)
    {
        retorno = 0;
        fscanf(pFile,"%[^,],%[^,],%[^\n]\n",bId,bNombre,bCantidad);
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^\n]\n",bId,bNombre,bCantidad);
         idEste = atoi(bId);
            cantidadEste = atoi(bCantidad);
            pAuxiliarProducto = producto_newParametros(idEste,bNombre,cantidadEste);
            al_add(this,pAuxiliarProducto);
        }
    }
    fclose(pFile);
    return retorno;
 }

 /*int controller_verificaEmpleados(ArrayList* this)
 {
     // eEmpleado* auxEmpleado;
     //auxEmpleado = al_get(this,1);

    ArrayList* pArrayEmpleadosJornadaCompleta;
    pArrayEmpleadosJornadaCompleta = al_newArrayList();

    pArrayEmpleadosJornadaCompleta = al_filter(this,producto_trabajaMasDe120Horas);
    controller_mostrarEmpleados(pArrayEmpleadosJornadaCompleta);
    controller_guardarEmpleadosArchivo("jornada_completa.txt",pArrayEmpleadosJornadaCompleta);
    return 0;
 }
 */


 int controller_mostrarProductos(ArrayList* this)
 {
     int retorno = -1;
    int i;
    eProducto* auxiliarEmpleado;
    char nombre[64];
    int id;
    int cantidad;


    if(this != NULL){
        retorno = 0;
        for(i = 0; i < al_len(this);i++)
        {
            auxiliarEmpleado= al_get(this,i);
            producto_getNombre(auxiliarEmpleado,nombre);
            producto_getId(auxiliarEmpleado,&id);
            producto_getCantidad(auxiliarEmpleado,&cantidad);
            printf("%d,%s,%d\n",id,nombre,cantidad);
        }
    }
return retorno;
 }

 int controller_guardarProductosArchivo(char* path, ArrayList* pArrayEmpleados)
{
    int retorno = -1;
    int i;
    eProducto* auxiliarProducto;
    char nombre[64];
    int id;
    int cantidad;
    FILE* pFile;
    pFile = fopen(path,"w+");
    if(pFile != NULL)
    {
    //fprintf(pFile,"id,nombre,apellido,dni\n");
        for(i=0;i<al_len(pArrayEmpleados);i++)
        {
            auxiliarProducto = al_get(pArrayEmpleados,i);
            producto_getId(auxiliarProducto,&id);
            producto_getNombre(auxiliarProducto,nombre);
            producto_getCantidad(auxiliarProducto,&cantidad);
            fprintf(pFile,"%d,%s,%d\n",id,nombre,cantidad);
        }
    }
    fclose(pFile);


    return retorno;
}

int controller_ListarproductosPorDeposito(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos)
{
    int retorno = -1;
    if(pArrayDepositoDos != NULL && pArrayDepositoUno != NULL)
    {
        retorno = 0;
        int aux;
        aux = view_pedirNumdeDeposito();
        if(aux == 1)
        {
        controller_mostrarProductos(pArrayDepositoUno);
        }
        if(aux == 2)
        {
        controller_mostrarProductos(pArrayDepositoDos);
        }

    }
    return retorno;
}


int controller_moverUnProductoEntreDepositos(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos)
{
    int retorno = -1;
    int origen;
    int id;

    eProducto* auxProducto;
    if(pArrayDepositoDos != NULL && pArrayDepositoUno != NULL)
    {
       origen =  view_pedirNumdeDepositoOrigen();
        id = view_pedirIdabuscar();

    if(origen == 1){
           auxProducto = producto_exiteIdEnDeposito(pArrayDepositoUno,id);
        if(auxProducto != NULL){
            view_mensajeCorrecto();
            al_add(pArrayDepositoDos,auxProducto);
        }
    }
      if(origen==2)
    {
       auxProducto = producto_exiteIdEnDeposito(pArrayDepositoDos,id);
         if(auxProducto != NULL){
            view_mensajeCorrecto();
            al_add(pArrayDepositoUno,auxProducto);
        }
    }
    }

return retorno;

}

int controller_DescontarProductosDeDeposito(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos)
{
    int retorno = -1;
    int i;
    int j;
    int id;
    int idAux;
    int idAux2;
    int cantidadAux;
    int cantidadDescontar;
    int cantidadFinal;
    if(pArrayDepositoUno != NULL && pArrayDepositoDos != NULL){
        retorno = 0;
        id = view_pedirIdabuscar();
        eProducto* auxiliarProducto;
        for(i=0; i<al_len(pArrayDepositoUno); i++)
        {
            auxiliarProducto = al_get(pArrayDepositoUno,i);
            producto_getId(auxiliarProducto,&idAux);
            if(idAux == id)
            {
                producto_getCantidad(auxiliarProducto,&cantidadAux);
                 cantidadDescontar = view_pedirCantidadaDescontar();
                 if(cantidadDescontar > -1 && cantidadDescontar <= cantidadAux)
                    {
                    cantidadFinal = cantidadAux - cantidadDescontar;
                    producto_setCantidad(auxiliarProducto,cantidadFinal);
                    al_set(pArrayDepositoUno,i,auxiliarProducto);
                    return retorno;
                    }

            }
        }

        for(j=0; i<al_len(pArrayDepositoDos); j++)
        {
        auxiliarProducto = al_get(pArrayDepositoDos,j);
        producto_getId(auxiliarProducto,&idAux2);
        if(idAux2 == id)
        {
        producto_getCantidad(auxiliarProducto,&cantidadAux);
         cantidadDescontar = view_pedirCantidadaDescontar();
         if(cantidadDescontar > -1 && cantidadDescontar <= cantidadAux)
            {
            cantidadFinal = cantidadAux - cantidadDescontar;
            producto_setCantidad(auxiliarProducto,cantidadFinal);
            al_set(pArrayDepositoDos,j,auxiliarProducto);
            }

        }
        }





    }


    return retorno;
}


int controller_AgregarProductosAlDeposito(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos)
{
        int retorno = -1;
        int i;
        int j;
        int id;
        int idAux;
        int cantidadAux;
        int cantidadSumar;
        int cantidadFinal;
        if(pArrayDepositoUno != NULL && pArrayDepositoDos != NULL){
            retorno = 0;
            id = view_pedirIdabuscar();
            eProducto* auxiliarProducto;
            for(i=0; i<al_len(pArrayDepositoUno); i++)
            {
            auxiliarProducto = al_get(pArrayDepositoUno,i);
            producto_getId(auxiliarProducto,&idAux);
            if(idAux == id)
            {
            producto_getCantidad(auxiliarProducto,&cantidadAux);
             cantidadSumar = view_pedirCantidadaSumar();
             if(cantidadSumar > -1)
                {
                cantidadFinal = cantidadAux + cantidadSumar;
                producto_setCantidad(auxiliarProducto,cantidadFinal);
                al_set(pArrayDepositoUno,i,auxiliarProducto);
                return retorno;
                }

            }
            }

            for(j=0; i<al_len(pArrayDepositoDos); j++)
            {
            auxiliarProducto = al_get(pArrayDepositoDos,j);
            producto_getId(auxiliarProducto,&idAux);
            if(idAux == id)
            {
            producto_getCantidad(auxiliarProducto,&cantidadAux);
             cantidadSumar = view_pedirCantidadaSumar();
             if(cantidadSumar > -1)
                {
                cantidadFinal = cantidadAux +cantidadSumar;
                producto_setCantidad(auxiliarProducto,cantidadFinal);
                al_set(pArrayDepositoDos,j,auxiliarProducto);
                }

            }
            }





    }


    return retorno;



}
