

#ifndef CONTROLLER_H_INCLUDED
#define CONTROLLER_H_INCLUDED

int controller_leerArchivoyGuardarEnArray(char* path, ArrayList* this);
 //int controller_verificaEmpleados(ArrayList* this);
  int controller_mostrarProductos(ArrayList* this);
  int controller_AgregarProductosAlDeposito(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos);
   int controller_guardarProductosArchivo(char* path, ArrayList* pArrayEmpleados);
    int controller_ListarproductosPorDeposito(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos);
    int controller_moverUnProductoEntreDepositos(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos);
int controller_DescontarProductosDeDeposito(ArrayList* pArrayDepositoUno, ArrayList* pArrayDepositoDos);
#endif // CONTROLLER_H_INCLUDED
