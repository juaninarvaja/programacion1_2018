#include "Producto.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "utn.h"
#include "controller.h"

eProducto* producto_new()
{
    eProducto* this;
    this=malloc(sizeof(eProducto));
    return this;
}
void producto_delete(eProducto* this)
{
    free(this);
}

int producto_setId(eProducto* this, int id)
{
    int retorno = -1;
    static int maximoId = -1;
    if(this != NULL)
    {
        retorno = 0;
        if(id >= 0)
        {
            this->id = id;
            if(id > maximoId)
                maximoId = id;
        }
        else
        {
            maximoId++;
            this->id = maximoId;
        }
    }
    return retorno;
}

int producto_getId(eProducto* this, int *id)
{
    int retorno = -1;
     if(this != NULL && id !=NULL){
        *id = this->id;
        retorno =0;
        }
    return retorno;
}
int producto_setNombre(eProducto* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int producto_getNombre(eProducto* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}


int producto_setCantidad(eProducto* this, int cantidad)
{
    int retorno = -1;
     if(this != NULL ){
        retorno =0;

            this->cantidad = cantidad;
        }
    return retorno;
}

int producto_getCantidad(eProducto* this, int *cantidad)
{
    int retorno = -1;
     if(this != NULL && cantidad !=NULL){
        *cantidad= this->cantidad;
        retorno =0;
        }
    return retorno;
}







eProducto* producto_newParametros(int id, char* nombre, int cantidad)
{

    eProducto* auxEmpleado = producto_new();
    if(!producto_setId(auxEmpleado,id) && !producto_setNombre(auxEmpleado,nombre) && !producto_setCantidad(auxEmpleado,cantidad))
    {
        return auxEmpleado;
    }

    producto_delete(auxEmpleado);
    return NULL;
}


eProducto* producto_exiteIdEnDeposito(ArrayList* pArray, int idCompare){

    if(pArray != NULL)
    {

        int i;
        int idAux;
        eProducto* auxiliarProducto;
        for(i=0; i<al_len(pArray); i++)
        {
        auxiliarProducto = al_get(pArray,i);
        producto_getId(auxiliarProducto,&idAux);

        if(idAux == idCompare){
            auxiliarProducto = al_pop(pArray,i);
            return auxiliarProducto;
        }
        }
    }
    return NULL;
}
