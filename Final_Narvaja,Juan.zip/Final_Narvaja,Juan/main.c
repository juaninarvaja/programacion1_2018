#include <stdio.h>
#include <stdlib.h>
#include "utn.h"
#include "ArrayList.h"
#include "controller.h"
#include "Producto.h"
#include "view.h"

int main()
{

    ArrayList* pArrayDepositoUno;
    ArrayList* pArrayDespositoDos;
    pArrayDepositoUno = al_newArrayList();
    pArrayDespositoDos = al_newArrayList();
    char seguir = 's';
    int opcion = 0;
    while(seguir=='s')
    {
        view_printMenu();
        scanf("%d",&opcion);
        fflush(stdin);

        switch(opcion)
        {
            case 1:
            if(!controller_leerArchivoyGuardarEnArray("dep0.csv",pArrayDepositoUno) && !controller_leerArchivoyGuardarEnArray("dep1.csv",pArrayDespositoDos))
            view_mensajeCorrecto();
                break;
            case 2:
                controller_ListarproductosPorDeposito(pArrayDepositoUno,pArrayDespositoDos);

                break;
            case 3:
                controller_moverUnProductoEntreDepositos(pArrayDepositoUno,pArrayDespositoDos);
                controller_guardarProductosArchivo("dep0.csv",pArrayDepositoUno);
                controller_guardarProductosArchivo("dep1.csv",pArrayDespositoDos);
               break;
            case 4:
                controller_DescontarProductosDeDeposito(pArrayDepositoUno,pArrayDespositoDos);
                 controller_guardarProductosArchivo("dep0.csv",pArrayDepositoUno);
                controller_guardarProductosArchivo("dep1.csv",pArrayDespositoDos);
                break;

            case 5:
                controller_AgregarProductosAlDeposito(pArrayDepositoUno,pArrayDespositoDos);
                controller_guardarProductosArchivo("dep0.csv",pArrayDepositoUno);
                controller_guardarProductosArchivo("dep1.csv",pArrayDespositoDos);
                break;

            case 6:
                seguir = 'n';
                break;
        }
    }

    return 0;
}

