#include <stdio.h>
#include <stdlib.h>
#include "utn.h"
//#include "peliculas.h"

void view_printMenu(){
      printf("\n1- Cargar en el Array \n");
        printf("2- Listar productos de deposito\n");
        printf("3- Mover productos a depostio\n");
        printf("4- Descontar productos de deposito\n");
        printf("5- Agregar productos al deposito \n");
        printf("6- Salir\n");
}

void view_mensajeCorrecto(){
printf("operacion con exito \n");

}


int view_pedirNumdeDeposito(){

    int numDeposito;
    if(!getValidInt("Ingrese el numero de deposito ","Error!",&numDeposito,1,2,5)){
        return numDeposito;
    }
    return -1;
}

int view_pedirNumdeDepositoOrigen()
{
    int numDeposito;
    if(!getValidInt("Ingrese el numero de deposito Origen ","Error!",&numDeposito,1,2,5)){
        return numDeposito;
    }
    return -1;

}
int view_pedirNumdeDeview_pedirCantidadaDescontar();  positoDestino()
{
    int numDeposito;
    if(!getValidInt("Ingrese el numero de deposito Destino","Error!",&numDeposito,1,2,5)){
        return numDeposito;
    }
    return -1;

}

int view_pedirIdabuscar(){
    int id;
     if(!getValidInt("Ingrese el id a buscar","Error!",&id,0,50,5)){
        return id;
    }
    return -1;


}

int view_pedirCantidadaDescontar()
{
   int cantidad;
     if(!getValidInt("Ingrese el cantidad a descontar","Error!",&cantidad,0,100,5)){
        return cantidad;
    }
    return -1;


}

int view_pedirCantidadaSumar(){
     int cantidad;
     if(!getValidInt("Ingrese el cantidad a sumar","Error!",&cantidad,0,100,5)){
        return cantidad;
    }
    return -1;


}
