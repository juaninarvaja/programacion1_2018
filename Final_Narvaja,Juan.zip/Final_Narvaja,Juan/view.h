
void view_printMenu();
void view_mensajeCorrecto();
int view_pedirNumdeDeposito();

int view_pedirNumdeDepositoOrigen();
int view_pedirNumdeDepositoDestino();
int view_pedirIdabuscar();
int view_pedirCantidadaDescontar();
int view_pedirCantidadaSumar();
