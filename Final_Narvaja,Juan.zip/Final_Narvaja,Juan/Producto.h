#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED
#include "ArrayList.h"
typedef struct
{
  int id;
  char nombre[128];
  int cantidad;
}eProducto;

eProducto* producto_new();
void producto_delete(eProducto* this);
int producto_trabajaMasDe120Horas(eProducto* unEmpleado);
//int em_trabajaMasDe120Horas(void* item);

eProducto* producto_newParametros(int id, char* nombre, int horas);
int producto_getCantidad(eProducto* this, int *cantidad);
int producto_setCantidad(eProducto* this, int horas);
int producto_getNombre(eProducto* this,char* nombre);
int producto_setNombre(eProducto* this,char* nombre);
int producto_getId(eProducto* this, int *id);
int producto_setId(eProducto* this, int id);
 eProducto* producto_exiteIdEnDeposito(ArrayList* pArray,int idCompare);
#endif // EMPLEADO_H_INCLUDED
