#include "clientes.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

eCliente* cliente_new()
{
    eCliente* this;
    this=malloc(sizeof(eCliente));
    return this;
}

void cliente_delete(eCliente* this)
{
    free(this);
}

int cliente_setNombre(eCliente* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int cliente_getNombre(eCliente* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int cliente_setApellido(eCliente* this,char* apellido)
{
    int retorno=-1;
    if(this!=NULL && apellido!=NULL)
    {
        strcpy(this->apellido,apellido);
        retorno=0;
    }
    return retorno;
}

int cliente_getApellido(eCliente* this,char* apellido)
{
    int retorno=-1;
    if(this!=NULL && apellido!=NULL)
    {
        strcpy(apellido,this->apellido);
        retorno=0;
    }
    return retorno;
}

int cliente_setDni(eCliente* this,char* dni)
{
    int retorno=-1;
    if(this!=NULL && dni!=NULL)
    {
        strcpy(this->dni,dni);
        retorno=0;
    }
    return retorno;
}

int cliente_getDni(eCliente* this,char* dni)
{
    int retorno=-1;
    if(this!=NULL && dni!=NULL)
    {
        strcpy(dni,this->dni);
        retorno=0;
    }
    return retorno;
}
int cliente_setId(eCliente* this, int id)
{
    int retorno = -1;
    static int maximoId = -1;
     if(this != NULL ){
        retorno =0;
        if(id >= 0){
            if(id > maximoId){
                maximoId = id;
                this->id = id;
            }
        }
        else{
            maximoId ++;
            this->id =maximoId;
        }

        }
    return retorno;

}

int cliente_getId(eCliente* this, int *id)
{
    int retorno = -1;
     if(this != NULL && id !=NULL){
        *id = this->id;
        retorno =0;
        }
    return retorno;
}


eCliente* cliente_newParametros(char* nombre,char* apellido, char* dni, char* id)
{
    eCliente* auxCliente = cliente_new();
    int idEste;
    idEste = atoi(id);

    if(!cliente_setNombre(auxCliente,nombre) && !cliente_setApellido(auxCliente,apellido) && !cliente_setDni(auxCliente,dni) && !cliente_setId(auxCliente,idEste))
    {
        return auxCliente;
    }
    cliente_delete(auxCliente);
    return NULL;
}

