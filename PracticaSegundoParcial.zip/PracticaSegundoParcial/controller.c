
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "utn.h"
#include "clientes.h"
#include "ventas.h"
#include "productos.h"

 int controller_leerArchivoyGuardarEnArrayCliente(char* path, ArrayList* pArrayClientes){
    char bNombre[4096];
    char bApellido[4096];
    char bDni[4056];
    char bId[4056];

    eCliente* pAuxiliarCliente;
    FILE* pFile;
    int retorno = -1;
    pFile = fopen(path,"r");
    if(pFile != NULL)
    {
        retorno = 0;
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^\n]\n",bId,bNombre,bApellido,bDni);
            pAuxiliarCliente = cliente_newParametros(bNombre,bApellido,bDni,bId);
            al_add(pArrayClientes,pAuxiliarCliente);
        }
    }
    fclose(pFile);
    return retorno;
 }


   int controller_leerArchivoyguardarEnArrayVentas(char* path,ArrayList* pArrayVentas)
   {
    char bIdVenta[4096];
    char bIdCliente[4096];
    char bCodigoProducto[4056];
    char bCantidad[4056];
    char bPrecioUnitario[4056];


    eVenta* pAuxiliarVenta;
    FILE* pFile;
    int retorno = -1;
    pFile = fopen(path,"r");
    if(pFile != NULL)
    {
        retorno = 0;
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[^,],%[^,],%[^,],%[^\n]\n",bIdVenta,bIdCliente,bCodigoProducto,bCantidad,bPrecioUnitario);
            pAuxiliarVenta = venta_newParametros(bIdVenta,bIdCliente,bCodigoProducto,bCantidad,bPrecioUnitario);
            al_add(pArrayVentas,pAuxiliarVenta);
        }
    }
    fclose(pFile);
    return retorno;
   }
