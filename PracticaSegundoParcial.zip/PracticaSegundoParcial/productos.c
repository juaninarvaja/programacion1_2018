#include "productos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


eProducto* producto_new()
{
    eProducto* this;
    this=malloc(sizeof(eProducto));
    return this;
}

int producto_setNombre(eProducto* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int producto_getNombre(eProducto* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int producto_setId(eProducto* this, int id)
{
    int retorno = -1;
     if(this != NULL ){
        retorno =0;
        if(id >= 0){
                this->id = id;
            }
        }
    return retorno;
}

int producto_getId(eProducto* this, int *id)
{
    int retorno = -1;
     if(this != NULL && id !=NULL){
        *id = this->id;
        retorno =0;
        }
    return retorno;
}

int producto_setPrecio(eProducto* this, float precio)
{
    int retorno = -1;
     if(this != NULL ){
        retorno =0;
        if(precio >= 0){
                this->precio = precio;
            }
        }
    return retorno;

}

int producto_getPrecio(eProducto* this, float*precio)
{
    int retorno = -1;
     if(this != NULL && precio !=NULL){
        *precio = this->precio;
        retorno =0;
        }
    return retorno;
}

eProducto* producto_altaForzadaProductos(char* nombre, float precio,int id)
    {


        if(nombre != NULL && id <= 0 && precio <= 0)
            {
                eProducto* auxProducto = producto_new();

                printf("entro?");
                producto_setNombre(auxProducto,nombre);
                producto_setId(auxProducto,id);
                producto_setPrecio(auxProducto, precio);
                return auxProducto;

            }
            return NULL;
}
