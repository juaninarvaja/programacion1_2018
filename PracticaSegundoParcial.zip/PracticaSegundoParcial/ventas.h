#ifndef VENTAS_H_INCLUDED
#define VENTAS_H_INCLUDED

typedef struct{
int id;
int id_cliente;
int codProducto;
int cantidad;
}eVenta;
eVenta* venta_new();
void venta_delete();


#endif // VENTAS_H_INCLUDED

