#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "productos.h"

int main()
{
    ArrayList* pArrayVentas;
    ArrayList* pArrayClientes;
    ArrayList* pArrayProductos;
    pArrayVentas = al_newArrayList();
    pArrayClientes = al_newArrayList();
    pArrayProductos = al_newArrayList();


    controller_leerArchivoyGuardarEnArrayCliente("clientes.txt", pArrayClientes);
    controller_leerArchivoyguardarEnArrayVentas("ventas.txt",pArrayVentas);


   /* char nombre[100];
    eProducto* auxProducto;
    auxProducto  = producto_altaForzadaProductos("tv_lg_32",8999,1000);

    al_add(pArrayProductos,auxProducto);
    auxProducto = al_get(pArrayProductos,0);
    producto_getNombre(auxProducto,nombre);
    printf("%s", nombre);



    printf("Hello world!\n");

    */

 return 0;
}
