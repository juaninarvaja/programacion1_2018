//#ifndef VIEW_H_INCLUDED
//#define VIEW_H_INCLUDED
//#include "peliculas.h"
void view_printMenu();
//void view_peliculaPrint(EMovie* arrayPeliculas, int len);

//#endif // VIEW_H_INCLUDED
