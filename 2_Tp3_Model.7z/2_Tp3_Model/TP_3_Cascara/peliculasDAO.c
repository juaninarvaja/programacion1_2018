
//DATA ACCES OBJECT
//las funciones que tienen q ver con obterner o guardar de/en un archivo
