#include <stdio.h>
#include <stdlib.h>
//#include "peliculas.h"

void view_printMenu(){
    printf("\n1- Agregar pelicula\n");
        printf("2- Borrar pelicula\n");
        printf("3- Modificar pelicula\n");
        printf("4- Generar pagina web\n");
        printf("5- Salir\n");
}

/* void view_peliculaPrint(EMovie *arrayPeliculas, int len)
{
    int i;
    printf("Id\t%20s\t%20s\t%s\t%s\t%25s\n","Titulo","Genero","Duracion","Puntaje","Descripcion");
    printf("---------------------------------------------------------------------------------------------------------\n");
    for(i=0; i<len; i++)
    {
        if (arrayPeliculas[i].flagOcupado)
        {
            printf("%d\t%20s\t%20s\t%8d\t%7.1f\t%22.20s...\n", arrayPeliculas[i].idPelicula, arrayPeliculas[i].titulo, arrayPeliculas[i].genero, arrayPeliculas[i].duracion, arrayPeliculas[i].puntaje,arrayPeliculas[i].descripcion);
        }
    }
}
*/
