#ifndef MODEL_H_INCLUDED
#define MODEL_H_INCLUDED

#define LEN_DESCRIPCION 1000
#define LEN_LINK 1000
#include "peliculas.h"


EMovie* model_getMovies(void);
int model_getMoviesLen(void);
int model_addMovie(EMovie pelicula);
int model_setMovie(int posicion,EMovie pelicula);
int model_deleteMovie(int posicion);


#endif // MODEL_H_INCLUDED
