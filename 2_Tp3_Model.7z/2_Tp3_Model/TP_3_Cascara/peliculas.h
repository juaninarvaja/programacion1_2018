#ifndef PELICULAS_H_INCLUDED
#define PELICULAS_H_INCLUDED

#define CANTIDAD_PELICULAS 10
#define LEN_DESCRIPCION 1000
#define LEN_LINK 1000

typedef struct{
    char titulo[20];
    char genero[20];
    int duracion;
    char descripcion[LEN_DESCRIPCION];
    float puntaje;
    char linkImagen[LEN_LINK];
    int flagOcupado;
    int idPelicula;
}EMovie;

#endif // PELICULAS_H_INCLUDED
