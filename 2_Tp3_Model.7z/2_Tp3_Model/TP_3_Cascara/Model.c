#include "Model.h"
#include "peliculas.h"
#include <stdlib.h>
#include "funciones.h"

#define CANTIDAD_PELICULAS 10

static EMovie arrayPeliculas[CANTIDAD_PELICULAS];


EMovie* model_getMovies(void)
{
    return arrayPeliculas;
}

int model_getMoviesLen(void)
{
    return CANTIDAD_PELICULAS;
}

int model_setMovie(int posicion, EMovie pelicula)
{
    int retorno = -1;
    if(posicion <= model_getMoviesLen())
    {
         arrayPeliculas[posicion] = pelicula;
         retorno = 1;
    }
    return retorno;
}
int model_addMovie(EMovie pelicula){
    int retorno = -1;
    int i;
    i =  pelicula_buscarPosicionLibre(arrayPeliculas,model_getMoviesLen());
    if(model_setMovie(i,pelicula)){
      retorno = 1;
    }
    return retorno;
}
int model_deleteMovie(int posicion){
    int retorno = -1;
    if(posicion <= model_getMoviesLen()){
        pelicula_baja(model_getMovies(),model_getMoviesLen(),posicion);
        retorno = 0;
    }
    return retorno;
}

