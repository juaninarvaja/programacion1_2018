#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED
typedef struct
{
    char nombre[50];
    char apellido[50];
    char cuit[20];
    //------------
    int idCliente;
    int isEmpty;
    int CantPublicaciones;
}eCliente;
#endif // CLIENTE_H_INCLUDED
int cliente_getNombre(eCliente* this, char* nombre);
int cliente_setNombre(eCliente* this,char* nombre);
int cliente_getApellido(eCliente* this, char* apellido);
int cliente_setApellido(eCliente* this, char* apellido);
int cliente_getCuit(eCliente* this, char* cuit);
int cliente_setCuit(eCliente* this, char* cuit);
int cliente_altaCliente(eCliente* this, int* sizeCliente);
