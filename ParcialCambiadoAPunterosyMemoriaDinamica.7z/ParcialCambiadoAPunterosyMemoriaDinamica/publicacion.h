#ifndef PUBLICACION_H_INCLUDED
#define PUBLICACION_H_INCLUDED

typedef struct
{
    //------------
    int idePublicacion;
    int idCliente;
    int rubro;
    char textoAviso[60];
    int isEmpty;
    int isActive;
}ePublicacion;
#endif // PUBLICACION_H_INCLUDED

int publicacion_getRubro(ePublicacion* this, int* rubro);
int publicacion_setRubro(ePublicacion* this, int rubro);
int publicacion_getAviso(ePublicacion* this, char* aviso);
int publicacion_setAviso(ePublicacion* this, char* aviso);
int publicacion_setIdCliente(ePublicacion* this, int idCliente);
int publicacion_getIdCliente(ePublicacion* this, int* idCliente);
