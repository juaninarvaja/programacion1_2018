#include <stdio.h>
#include <stdlib.h>
#include "publicacion.h"
#include "cliente.h"

int main()
{
    char auxNombre[50];
    int *sizeCliente;
    sizeCliente = 1;
    ePublicacion* arrayPunterosPublicacion;
    eCliente* arrayPunterosClientes;
    arrayPunterosClientes = (int *)malloc(sizeof(eCliente) * 10);
    arrayPunterosPublicacion = (int *)malloc(sizeof(ePublicacion) * 10);
    cliente_altaCliente(arrayPunterosClientes,sizeCliente);

   /* printf("ingrese el nombre a cargar");
    fflush(stdin);
    gets(auxNombre);
    cliente_setNombre(arrayPunterosClientes,auxNombre);
    printf("%s", arrayPunterosClientes->nombre);
*/
    return 0;
}
