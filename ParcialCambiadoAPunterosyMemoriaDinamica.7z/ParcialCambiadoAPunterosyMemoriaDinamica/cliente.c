#include <stdio.h>
#include <stdlib.h>
#include "cliente.h"
#include <string.h>

int cliente_setNombre(eCliente* this,char* nombre){
    int retorno = -1;
    if(this != NULL && nombre >= 0){

        strcpy(this->nombre,nombre);
        retorno = 0;
    }
    return retorno;

}
int cliente_getNombre(eCliente* this,char* nombre){
    int retorno = -1;
    if(this != NULL && nombre != NULL){

        strcpy(nombre,this->nombre);
         retorno = 0;
        }
    return retorno;
}

int cliente_setApellido(eCliente* this, char* apellido){
    int retorno = -1;
    if(this != NULL && apellido >= 0){

        strcpy(this->apellido,apellido);
        retorno = 0;
    }
    return retorno;

}
int cliente_getApellido(eCliente* this, char* apellido){
    int retorno = -1;
    if(this != NULL && apellido != NULL){

        strcpy(apellido,this->apellido);
         retorno = 0;
        }
    return retorno;
}
int cliente_setCuit(eCliente* this, char* cuit){
    int retorno = -1;
    if(this != NULL && cuit >= 0){

        strcpy(this->cuit,cuit);
        retorno = 0;
    }
    return retorno;

}
int cliente_getCuit(eCliente* this, char* cuit){
    int retorno = -1;
    if(this != NULL && cuit != NULL){

        strcpy(cuit,this->cuit);
         retorno = 0;
        }
    return retorno;
}

int cliente_altaCliente(eCliente* this, int* sizeClientes){
    int retorno = -1;
    char nombre[50];

    if(this != NULL){
        while(1){

        printf("ingrese el nombre a cargar ");
        fflush(stdin);
        gets(nombre);
        cliente_setNombre((this+*sizeClientes-1),nombre);
        printf("el nombre es: %s", (this+*sizeClientes-1)->nombre);
        *sizeClientes ++;
        printf("ingrese el nombre a cargar ");
        fflush(stdin);
        gets(nombre);
        cliente_setNombre((this+*sizeClientes-1),nombre);
        printf("el nombre es: %s", (this+*sizeClientes-1)->nombre);
        }

            }
return retorno;
    }

