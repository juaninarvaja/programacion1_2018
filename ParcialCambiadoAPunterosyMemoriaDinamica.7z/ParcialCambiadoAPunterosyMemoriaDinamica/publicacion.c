#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "publicacion.h"

int publicacion_setRubro(ePublicacion* this, int rubro){
    int retorno = -1;
    if(this != NULL && rubro >= 0){
        this->rubro = rubro;
        retorno = 0;
    }
    return retorno;
}

int publicacion_getRubro(ePublicacion* this, int* rubro){
    int retorno = -1;
    if(this != NULL && rubro != NULL){

        *rubro = this->rubro;
        retorno = 0;
        }
    return retorno;
}

int publicacion_setIdCliente(ePublicacion* this, int idCliente){
    int retorno = -1;
    if(this != NULL && idCliente >= 0){
        this->idCliente = idCliente;
        retorno = 0;
    }
    return retorno;
}

int publicacion_getIdCliente(ePublicacion* this,int* idCliente){
    int retorno = -1;
    if(this != NULL && idCliente != NULL){

        *idCliente = this->idCliente;
        retorno = 0;
        }
    return retorno;
}

int publicacion_setAviso(ePublicacion* this, char* aviso){
    int retorno = -1;
    if(this != NULL && aviso >= 0){

        strcpy(this->textoAviso,aviso);
        retorno = 0;
    }
    return retorno;

}
int publicacion_getAviso(ePublicacion* this, char* aviso){
    int retorno = -1;
    if(this != NULL && aviso != NULL){

        strcpy(aviso,this->textoAviso);
         retorno = 0;
        }
    return retorno;
}
