#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ArrayList.h"
#include "utn.h"
#include "destinatarios.h"


int controller_leerArchivoDestinatario(char* path, ArrayList* pArrayDestinatarios)
{
    char bNombre[4096];
    char bMail[4096];

    eDestinatario* pAuxiliarDestinatario;
    FILE* pFile;
    int retorno = -1;
    pFile = fopen(path,"r");
    if(pFile != NULL)
    {
        retorno = 0;
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[\n]\n",bNombre,bMail);
            pAuxiliarDestinatario = destinatarios_newParametros(bNombre,bMail);
            al_add(pArrayDestinatarios,pAuxiliarDestinatario);
        }
    }
    fclose(pFile);
    return retorno;
}

int controller_listarDestinatarios(ArrayList* pArrayDestinatarios)
{
    int retorno = -1;
    int i;
    eDestinatario* auxiliarDestinatario;
    char nombre[64];
    char mail[256];


    for(i=0;i<al_len(pArrayDestinatarios);i++)
    {
        auxiliarDestinatario= al_get(pArrayDestinatarios,i);
        destinatarios_getNombre(auxiliarDestinatario,nombre);
        destinatarios_getMail(auxiliarDestinatario,mail);
        printf("%s - %s",nombre,mail);
    }
    return retorno;
}

int controller_leerArchivoBlackList(char* path, ArrayList* pArrayBlackList)
{
    char bNombre[4096];
    char bMail[4096];

    eDestinatario* pAuxiliarBlackList;
    FILE* pFile;
    int retorno = -1;
    pFile = fopen(path,"r");
    if(pFile != NULL)
    {
        retorno = 0;
        while(!feof(pFile))
        {
            fscanf(pFile,"%[^,],%[\n]\n",bNombre,bMail);
            pAuxiliarBlackList = destinatarios_newParametros(bNombre,bMail);
            al_add(pArrayBlackList,pAuxiliarBlackList);
        }
    }
    fclose(pFile);
    return retorno;
}

int controller_listarBlackList(ArrayList* pArrayBlackList)
{
    int retorno = -1;
    int i;
    eDestinatario* auxiliarBlackList;
    char nombre[64];
    char mail[256];


    for(i=0;i<al_len(pArrayBlackList);i++)
    {
        auxiliarBlackList= al_get(pArrayBlackList,i);
        destinatarios_getNombre(auxiliarBlackList,nombre);
        destinatarios_getMail(auxiliarBlackList,mail);
        printf("%s - %s",nombre,mail);
    }
    return retorno;
}


/*int controller_ordenarClientesNombreApellido(ArrayList* pArrayClientes)
{
    int retorno = -1;
    if(pArrayClientes != NULL)
    {
        retorno = 0;
        al_sort(pArrayClientes,cliente_ordenarNombreApellido,1);
    }
    return retorno;
}
*/

int controller_guardarDestinatariosArchivo(char* path, ArrayList* pArrayWhiteList)
{
    int retorno = -1;
    eDestinatario* auxiliarDestinatario;
    char nombre[64];
    char mail[256];
    int i;
    FILE* pFile;
    pFile = fopen(path,"w");
    if(pFile != NULL)
    {

        for(i=0;i<al_len(pArrayWhiteList);i++)
        {
            auxiliarDestinatario= al_get(pArrayWhiteList,i);
            destinatarios_getNombre(auxiliarDestinatario,nombre);
            destinatarios_getMail(auxiliarDestinatario,mail);
            fprintf(pFile,"%s,%s\n",nombre,mail);

        }
    }
    fclose(pFile);


    return retorno;
}




