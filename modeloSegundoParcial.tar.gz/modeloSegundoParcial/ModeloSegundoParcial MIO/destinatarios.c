#include "destinatarios.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

eDestinatario* destinatarios_new()
{
    eDestinatario* this;
    this=malloc(sizeof(eDestinatario));
    return this;
}

void destinatarios_delete(eDestinatario* this)
{
    free(this);
}

int destinatarios_setNombre(eDestinatario* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int destinatarios_getNombre(eDestinatario* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int destinatarios_setMail(eDestinatario* this,char* mail)
{
    int retorno=-1;
    if(this!=NULL && mail!=NULL)
    {
        strcpy(this->mail,mail);
        retorno=0;
    }
    return retorno;
}

int destinatarios_getMail(eDestinatario* this,char* mail)
{
    int retorno=-1;
    if(this!=NULL && mail!=NULL)
    {
        strcpy(mail,this->mail);
        retorno=0;
    }
    return retorno;
}
eDestinatario* destinatarios_newParametros(char* nombre,char* mail)
{
    eDestinatario* auxDestinatario = destinatarios_new();
    if(!destinatarios_setNombre(auxDestinatario,nombre) && !destinatarios_setMail(auxDestinatario,mail))
    {
        return auxDestinatario;
    }
    destinatarios_delete(auxDestinatario);
    return NULL;
}

