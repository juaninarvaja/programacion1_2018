#ifndef CONTROLER_H_INCLUDED
#define CONTROLER_H_INCLUDED


#endif // CONTROLER_H_INCLUDED

int controller_leerArchivoDestinatario(char* path, ArrayList* pArrayClientes);
int controller_listarDestinatarios(ArrayList* pArrayDestinatarios);

int controller_leerArchivoBlackList(char* path, ArrayList* pArrayClientes);
int controller_listarBlackList(ArrayList* pArrayDestinatarios);
int controller_guardarDestinatariosArchivo(char* path, ArrayList* pArrayWhiteList);
