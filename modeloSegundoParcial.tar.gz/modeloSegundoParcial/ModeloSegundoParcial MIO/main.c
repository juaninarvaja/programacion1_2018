#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
#include "destinatarios.h"
#include "utn.h"
#include "controller.h"


int main()
{
    ArrayList* pArrayDestinatarios;
    pArrayDestinatarios = al_newArrayList();
    ArrayList* pArrayBlackList;
    pArrayBlackList = al_newArrayList();
    ArrayList* pArrayWhiteList;
    pArrayWhiteList=al_newArrayList();


    controller_leerArchivoDestinatario("destinatarios.csv",pArrayDestinatarios);
    controller_leerArchivoBlackList("black_list.csv",pArrayBlackList);
   // controller_listarDestinatarios(pArrayDestinatarios);
   //controller_listarBlackList(pArrayBlackList);
    pArrayWhiteList = al_returnWhiteList(pArrayDestinatarios,pArrayBlackList);

    int aux,aux2,aux3;
    aux = al_len(pArrayWhiteList);
    aux2= al_len(pArrayDestinatarios);
    aux3 = al_len(pArrayBlackList);
    printf("%d - %d -%d",aux,aux2,aux3);
   //controller_guardarDestinatariosArchivo("whitelist.csv",pArrayWhiteList);







    return 0;
}
